import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import Dashboard from './pages/Dashboard';
import AdminSmDashboard from './pages/AdminSmDashboard';
import AdminCmSkuDetail from './pages/AdminCmSkuDetail';
import SedForApproval from './pages/SedForApproval';
import GeneratePdf from './pages/GeneratePdf';
import UploadData from './pages/UploadData';
import AuditLog from './pages/AuditLog';
import CmSkuDetail from './pages/CM/CmSkuDetail';
import CmSedForApproval from './pages/CM/CmSedForApproval';
import CmGeneratePdf from './pages/CM/CmGeneratePdf';
import SrmDashboard from './pages/SRM/SrmDashboard';
import SrmSkuDetail from './pages/SRM/SrmSkuDetail';
import ProtectedRoute from './components/ProtectedRoute';
import SSOProvider from './components/SSOProvider';
import SecurityTester from './components/SecurityTester';
import SSOInterceptor from './components/SSOInterceptor';
import SSOButton from './components/SSOButton';

import './assets/css/styles.css';
import './assets/css/remix-icon.css';
import './assets/css/multi-select.css';
import './assets/css/pagination.css';
import './assets/css/sso-button.css';

function App() {
  return (
    <SSOProvider>
      <Router>
        <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/landing" element={<LandingPage />} />
        <Route path="/dashboard" element={<Navigate to="/admin/cm-dashboard" replace />} />
        <Route path="/dasbboard" element={<Navigate to="/admin/cm-dashboard" replace />} />
        
        {/* Admin Routes - Only accessible by Role 1 users */}
        <Route path="/admin/cm-dashboard" element={
          <SSOInterceptor>
            <ProtectedRoute requireAdmin={true}>
              <AdminSmDashboard />
            </ProtectedRoute>
          </SSOInterceptor>
        } />
        <Route path="/admin/cm-sku-details" element={
          <SSOInterceptor>
            <ProtectedRoute requireAdmin={true}>
              <AdminCmSkuDetail />
            </ProtectedRoute>
          </SSOInterceptor>
        } />
        <Route path="/admin/cm/:cmCode" element={
          <SSOInterceptor>
            <ProtectedRoute requireAdmin={true}>
              <AdminCmSkuDetail />
            </ProtectedRoute>
          </SSOInterceptor>
        } />
        
        {/* CM User Route - Only accessible by Role 2 users */}
        <Route path="/cm/cm-sku-detail/:cmCode" element={
          <SSOInterceptor>
            <ProtectedRoute requireCMUser={true}>
              <CmSkuDetail />
            </ProtectedRoute>
          </SSOInterceptor>
        } />
        
        {/* CM-specific routes - Only accessible by Role 2 users */}
        <Route path="/cm/sedforapproval" element={
          <SSOInterceptor>
            <ProtectedRoute requireCMUser={true}>
              <CmSedForApproval />
            </ProtectedRoute>
          </SSOInterceptor>
        } />
        <Route path="/cm/generate-pdf" element={
          <SSOInterceptor>
            <ProtectedRoute requireCMUser={true}>
              <CmGeneratePdf />
            </ProtectedRoute>
          </SSOInterceptor>
        } />
        
        {/* SRM User Route - Only accessible by Role 3 users */}
        <Route path="/srm/srm-dashboard" element={
          <SSOInterceptor>
            <ProtectedRoute requireSRMUser={true}>
              <SrmDashboard />
            </ProtectedRoute>
          </SSOInterceptor>
        } />
        
        {/* SRM SKU Detail Route - Only accessible by Role 3 users */}
        <Route path="/srm/sku-detail/:cmCode" element={
          <SSOInterceptor>
            <ProtectedRoute requireSRMUser={true}>
              <SrmSkuDetail />
            </ProtectedRoute>
          </SSOInterceptor>
        } />
        
        {/* Debug route to test if routing is working */}
        <Route path="/srm/test-route" element={
          <SSOInterceptor>
            <div style={{ padding: '20px', textAlign: 'center' }}>
              <h1>Test Route Working!</h1>
              <p>If you can see this, routing is working correctly.</p>
            </div>
          </SSOInterceptor>
        } />
        
        {/* Other Routes */}
        <Route path="/sedforapproval" element={
          <SSOInterceptor>
            <SedForApproval />
          </SSOInterceptor>
        } />
        <Route path="/generate-pdf" element={
          <SSOInterceptor>
            <GeneratePdf />
          </SSOInterceptor>
        } />
        <Route path="/upload-data" element={
          <SSOInterceptor>
            <UploadData />
          </SSOInterceptor>
        } />
        
        {/* Audit Log Route - Accessible to all authenticated users */}
        <Route path="/audit-log" element={
          <SSOInterceptor>
            <ProtectedRoute>
              <AuditLog />
            </ProtectedRoute>
          </SSOInterceptor>
        } />
        
        {/* Remove the incorrect route */}
        {/* <Route path="/ng in this " element={
          <SSOInterceptor>
            <AuditLog />
          </SSOInterceptor>
        } /> */}
        
        <Route path="/security-tester" element={
          <SSOInterceptor>
            <SecurityTester />
          </SSOInterceptor>
        } />
        </Routes>
      </Router>
    </SSOProvider>
  );
}

export default App;
