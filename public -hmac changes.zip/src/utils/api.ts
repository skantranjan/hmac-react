// API utility functions with HMAC authentication
import CryptoJS from 'crypto-js';
import moment from 'moment';

// HMAC Configuration
const HMAC_CONFIG = {
  ID: 'SustainibilityPortal',
  KEY: '0KEX8P1I7U9NJHKV1L7XHCVH6QI9XXCS',
  API_KEY: 'bGMxYSqsNUb6F88L9rTY3OOMCynzZKAF',
  // Use relative URL in development (with proxy) or full URL in production
  BASE_URL: process.env.NODE_ENV === 'development' 
    ? '/Sustainibility-portal-channel/v1' 
    : 'https://haleon-api-dev.apigee.net/Sustainibility-portal-channel/v1'
};

// HMAC Generation Functions
const generateTimestamp = (): string => {
  const date = new Date();
  return moment.utc(date).format('YYYY-MM-DDTHH:mm:ss[Z]');
};

const generateHMAC = (method: string, timestamp: string): string => {
  const dataString = `${method}${HMAC_CONFIG.ID}${timestamp}`;
  const hash = CryptoJS.HmacSHA256(dataString, HMAC_CONFIG.KEY);
  return CryptoJS.enc.Base64.stringify(hash);
};

// Debug function to test HMAC generation (can be removed in production)
export const testHMACGeneration = (): void => {
  const timestamp = generateTimestamp();
  console.log('🔐 HMAC Test Results:');
  console.log('Timestamp:', timestamp);
  console.log('GET HMAC:', generateHMAC('GET', timestamp));
  console.log('POST HMAC:', generateHMAC('POST', timestamp));
  console.log('PUT HMAC:', generateHMAC('PUT', timestamp));
  console.log('DELETE HMAC:', generateHMAC('DELETE', timestamp));
};

// Helper function to create headers with HMAC authentication
const createHeaders = (method: string, contentType?: string): HeadersInit => {
  const headers: HeadersInit = {};
  const timestamp = generateTimestamp();
  const hmacHash = generateHMAC(method, timestamp);
  
  // HMAC Authentication Headers
  headers['X-Timestamp'] = timestamp;
  headers['X-HMAC'] = hmacHash;
  headers['X-API-Key'] = HMAC_CONFIG.API_KEY;
  
  if (contentType) {
    headers['Content-Type'] = contentType;
  }
  
  return headers;
};

// GET request helper
export const apiGet = async (endpoint: string, params?: Record<string, any>): Promise<any> => {
  let url = `${HMAC_CONFIG.BASE_URL}${endpoint}`;
  
  // Add query parameters if provided
  if (params && Object.keys(params).length > 0) {
    const queryParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        queryParams.append(key, value.toString());
      }
    });
    if (queryParams.toString()) {
      url += `?${queryParams.toString()}`;
    }
  }
  
  const response = await fetch(url, {
    method: 'GET',
    headers: createHeaders('GET')
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return response.json();
};

// POST request helper
export const apiPost = async (endpoint: string, data: any, contentType: string = 'application/json'): Promise<any> => {
  const body = contentType === 'application/json' ? JSON.stringify(data) : data;
  
  const response = await fetch(`${HMAC_CONFIG.BASE_URL}${endpoint}`, {
    method: 'POST',
    headers: createHeaders('POST', contentType),
    body
  });
  
  if (!response.ok) {
    // Try to get the error message from the response
    let errorMessage = `HTTP error! status: ${response.status}`;
    try {
      const errorData = await response.json();
      if (errorData.message) {
        errorMessage = `${errorMessage} - ${errorData.message}`;
      }
    } catch (e) {
      // If we can't parse the response, use the status text
      errorMessage = `${errorMessage} - ${response.statusText}`;
    }
    throw new Error(errorMessage);
  }
  
  return response.json();
};

// PUT request helper
export const apiPut = async (endpoint: string, data: any, contentType: string = 'application/json'): Promise<any> => {
  const body = contentType === 'application/json' ? JSON.stringify(data) : data;
  
  const response = await fetch(`${HMAC_CONFIG.BASE_URL}${endpoint}`, {
    method: 'PUT',
    headers: createHeaders('PUT', contentType),
    body
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return response.json();
};

// PATCH request helper
export const apiPatch = async (endpoint: string, data: any): Promise<any> => {
  const response = await fetch(`${HMAC_CONFIG.BASE_URL}${endpoint}`, {
    method: 'PATCH',
    headers: createHeaders('PATCH', 'application/json'),
    body: JSON.stringify(data)
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return response.json();
};

// DELETE request helper
export const apiDelete = async (endpoint: string): Promise<any> => {
  const response = await fetch(`${HMAC_CONFIG.BASE_URL}${endpoint}`, {
    method: 'DELETE',
    headers: createHeaders('DELETE')
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  return response.json();
};

// POST request helper with query parameters
export const apiPostWithParams = async (endpoint: string, params?: Record<string, any>, data?: any): Promise<any> => {
  let url = `${HMAC_CONFIG.BASE_URL}${endpoint}`;
  
  // Add query parameters if provided
  if (params && Object.keys(params).length > 0) {
    const queryParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        queryParams.append(key, value.toString());
      }
    });
    if (queryParams.toString()) {
      url += `?${queryParams.toString()}`;
    }
  }
  
  // Ensure we always have a valid body for POST requests
  const requestBody = data || {};
  
  const response = await fetch(url, {
    method: 'POST',
    headers: createHeaders('POST', 'application/json'),
    body: JSON.stringify(requestBody)
  });
  
  if (!response.ok) {
    // Try to get the error message from the response
    let errorMessage = `HTTP error! status: ${response.status}`;
    try {
      const errorData = await response.json();
      if (errorData.message) {
        errorMessage = `${errorMessage} - ${errorData.message}`;
      }
    } catch (e) {
      // If we can't parse the response, use the status text
      errorMessage = `${errorMessage} - ${response.statusText}`;
    }
    throw new Error(errorMessage);
  }
  
  return response.json();
};

// For FormData requests (no Content-Type header needed)
export const apiPostFormData = async (endpoint: string, formData: FormData): Promise<Response> => {
  const response = await fetch(`${HMAC_CONFIG.BASE_URL}${endpoint}`, {
    method: 'POST',
    headers: createHeaders('POST'),
    body: formData
  });
  
  // Return the response object instead of throwing an error
  // This allows the calling code to handle validation errors properly
  return response;
};

export const apiPutFormData = async (endpoint: string, formData: FormData): Promise<Response> => {
  const response = await fetch(`${HMAC_CONFIG.BASE_URL}${endpoint}`, {
    method: 'PUT',
    headers: createHeaders('PUT'),
    body: formData
  });
  
  // Return the response object instead of throwing an error
  // This allows the calling code to handle validation errors properly
  return response;
}; 